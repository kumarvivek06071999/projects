export const ADD_TOKEN = "add/token"
export const DELETE_TOKEN = "delete/token"