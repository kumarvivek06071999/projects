<center><h1>Overstock.com</h1></center>
# About
<center>Overstock is an online home products retailer that sells furniture, rugs, kitchen appliances and bathroom accessories.
Overstock’s inventory also includes clothing, jewelry and children’s items.</center>
<center><img src="https://drive.google.com/uc?export=view&id=15zdFoSJeu0e6TQV-B4E7qMxo70Mjx7ja" width="90%"></img></center>

# Tech stack
 - `HTML`
 - `CSS`
 - `JavaScript`
 - `Local storage`

# Pages
 - `Product page`
 - `Fav Page`
 - `Cart Page`
 - `Payment page`
 
# Features
 - `Login/Signup`
 - `Sorting`


<center><h1>Deployed Link</h1></center>
<center><a href="https://overstock-light-deer-8425.netlify.app/" target="_blank">Demo</a></center>

