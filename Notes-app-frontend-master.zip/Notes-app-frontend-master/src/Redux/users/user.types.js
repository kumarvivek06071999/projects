export const LOGIN_USER_LOADING = "login/user/loading" 
export const LOGIN_USER_SUCCESS = "login/user/success" 
export const LOGIN_USER_ERROR = "login/user/error" 

export const LOGOUT = "logout"
