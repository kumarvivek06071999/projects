export const CONTAINER = "200px"
export const ADMIN = "admin"
export const SUPER_ADMIN = "superadmin"
export const USER = "user"
export const DEACTIVATE = "deactivate"
export const DELETE = "delete"
//Add more categories
export const SHIRT = "shirt"
export const TOP = "top"
export const KURTIS = "Kurtis"
export const PARTY_WEAR = "party-wear"
export const RUPEES_SYMBOL = "₹"

//status
export const ORDERED ="ordered"
export const DELIVERED ="delivered"
export const DISPATCHED ="dispatched"
export const CANCELLED ="cancelled"