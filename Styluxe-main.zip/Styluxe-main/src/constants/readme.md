This folder is very important , We use to keep all the configuration and typography here.
You can make your constant files and use it in your project.
