# Youtube-Clone
This is a basic the clone of YouTube using YouTube API . You can watch any youtube video which publicly available on youtube .
I have used iframe for playing video. Also you search any video and filter it by  date,view-count,video-count,relavance etc..

<center><img src="https://drive.google.com/uc?export=view&id=1O4Coh1KzFNCf2vsrE-M-QXKEkltt44el" width="90%"></img></center>

# Tech Satck
 - `HTML`
 - `CSS`
 - `JavaScript`
 - `Youtube API`

# Features
- Search any video which is publicly available on YouTube <br/>
- Watch any Video (used iframe) <br/>
- Filter by Relavance, Video count, Date, View Count etc.. <br/>
- Debouncing algo for api optimization

# Deployed Link
<a href="https://youtube-fw21-1003.netlify.app/">Demo</a>
