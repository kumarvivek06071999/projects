import { Box } from "@chakra-ui/react";
import React from "react";

const MyReviews = () => {
  return <Box>No Reviews</Box>;
};

export default MyReviews;
