export default function my_border(px,type,color){


    return `${px}px ${type} ${color}`
}