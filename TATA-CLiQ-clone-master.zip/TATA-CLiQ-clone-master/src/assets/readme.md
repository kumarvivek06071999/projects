How to import images?
`import anyname from "./location/anyname.png"`

How to use it?
`<Image src={anyname} />`