// import { useSelector } from "react-redux";
// import Homepage from "../pages/Homepage";

// export default function ProtectAdmin({children}){

//     const  {userId} = useSelector((state)=>state.authManager)

//     if(userId.email=="admin@gmail.com"){
//         return children
//     }
//     return <Homepage />

// }