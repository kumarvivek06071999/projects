// on login page
export const ADMIN_LOGIN_REQUEST = 'admin/ADMIN_LOGIN_REQUEST';
export const ADMIN_LOGIN_SUCCESS = 'admin/ADMIN_LOGIN_SUCCESS';
export const ADMIN_LOGIN_FAILURE = 'admin/ADMIN_LOGIN_FAILURE';
export const ADMIN_LOGIN_RESET = 'admin/ADMIN_LOGIN_RESET';