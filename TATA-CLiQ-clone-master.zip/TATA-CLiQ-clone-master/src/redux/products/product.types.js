export const LODING_PRODUCTS = "loading/products"
export const SUCCESS_PRODUCTS = "success/products"
export const ERROR_PRODUCTS = "error/products"
