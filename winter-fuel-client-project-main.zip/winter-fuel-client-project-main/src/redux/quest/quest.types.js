export const GET_QUEST_LOADING = "get/quest/loading"
export const GET_QUEST_SUCCESS = "get/quest/success"
export const GET_QUEST_ERROR = "get/quest/error"

export const CREATE_QUEST_LOADING = "create/quest/loading"
export const CREATE_QUEST_SUCCESS = "create/quest/success"
export const CREATE_QUEST_ERROR = "create/quest/error"


export const UPDATE_QUEST_LOADING = "update/quest/loading"
export const UPDATE_QUEST_SUCCESS = "update/quest/success"
export const UPDATE_QUEST_ERROR = "update/quest/error"


export const DELETE_QUEST_LOADING = "delete/quest/loading"
export const DELETE_QUEST_SUCCESS = "delete/quest/success"
export const DELETE_QUEST_ERROR = "delete/quest/error"