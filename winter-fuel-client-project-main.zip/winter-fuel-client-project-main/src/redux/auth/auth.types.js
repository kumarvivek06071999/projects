export const LOGIN_LOADING = "login/loading"
export const LOGIN_ERROR = "login/error"
export const LOGIN_SUCCESS = "login/success"
export const LOGOUT = "logout"