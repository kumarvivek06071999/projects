function nav(){
    return `<div>
    <i class="fa-solid fa-bars"></i>
    <img id="logo" src="https://secure-media.hotstarext.com/web-assets/prod/images/brand-logos/disney-hotstar-logo-dark.svg" alt="">
    <p>TV</p>
    <p>Movies</p>
    <p>Sports</p>
    <p>Disney+</p>
    <img src="https://secure-media.hotstarext.com/web-assets/prod/images/brand-logos/disney-kids.svg" alt="">
</div>

<div>
    <div id="search-Div">
        <input id="search" type="text" placeholder="Search" autocomplete="off">
        <div>
            <!-- appenData -->
            <!-- <div>
                <div id="demo">
                    <img src="https://ichef.bbci.co.uk/news/640/cpsprodpb/BF0D/production/_106090984_2e39b218-c369-452e-b5be-d2476f9d8728.jpg" alt="">
                </div>
                <h3>Avangers</h3>
            </div>
            <div>
                <div id="demo">
                    <img src="https://ichef.bbci.co.uk/news/640/cpsprodpb/BF0D/production/_106090984_2e39b218-c369-452e-b5be-d2476f9d8728.jpg" alt="">
                </div>
                <h3>Avengers</h3>
            </div> -->

        </div>

    </div>
    <img id="login" src="https://cdn-icons-png.flaticon.com/128/954/954591.png" alt="">

</div>`
}

export default nav