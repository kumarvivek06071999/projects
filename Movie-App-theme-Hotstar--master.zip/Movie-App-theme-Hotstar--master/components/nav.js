function nav(){
    return `<div>
        <i class="fa-solid fa-bars"></i>
        <img id="logo" src="https://secure-media.hotstarext.com/web-assets/prod/images/brand-logos/disney-hotstar-logo-dark.svg" alt="">
        <p>TV</p>
        <p>Movies</p>
        <p>Sports</p>
        <p>Disney+</p>
        <img src="https://secure-media.hotstarext.com/web-assets/prod/images/brand-logos/disney-kids.svg" alt="">
    </div>

    <div>
        <input id="search" type="text" placeholder="Search">
        <img id="login" src="https://www.hotstar.com/assets/c724e71754181298e3f835e46ade0517.svg" alt="">

    </div>`
}

export default nav