
import nav from "../components/nav.js";
import fot from "../components/fot.js"

document.getElementById("navbar").innerHTML=nav();
document.getElementById("footer").innerHTML=fot();
