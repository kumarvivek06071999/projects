function utility(){
    return `<div id="time-always-tab">


    <div>
        <div>
            <h3 style="font-size: 20px;">Getting started with Time Always</h3>
            <div class="w3-light-grey w3-round-xlarge" style="margin: auto; width: 200px; height:5px;">
                <div class="w3-container w3-blue w3-round-xlarge" style="width:25% ; height: 5px;"></div>
              </div>
              <h3>25%</h3>

        </div>
        <a href=""><h3>Help</h3></a>
    </div>

    <div>

        <button id="stt"><i class="fa-solid fa-circle-check"></i>&nbspStart tracking time</button>
        <button id="create"><i class="fa-solid fa-circle-check"></i>&nbspCreate project</button>
        <button id="desktop-app"><i class="fa-solid fa-circle-check"></i>&nbspDesktop App</button>
        <button id="wt"><i class="fa-solid fa-circle-check"></i>&nbspWeb timer</button>
        <button id="ets"><i class="fa-solid fa-circle-check"></i>&nbspEdit the settings</button>
        <button id="sta"><i class="fa-solid fa-circle-check"></i>&nbspSubscribe to Time Always</button>
    </div>


</div>`
}

export default utility