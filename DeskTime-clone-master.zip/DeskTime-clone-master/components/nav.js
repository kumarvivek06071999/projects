function nav() {
    return `<div>
    <img id = "logo" src="/assets/Screenshot 2022-11-08 194854.png" alt="">
</div>
<div>
    <a href="demo.html">Demo</a>
    <a href="features.html">Feature</a>
    <a href="price.html">Pricing</a>
    <a href="aboutus.html">About Us</a>
    <a href="faq.html">FAQ</a>
    <a href="https://desktime.com/blog/">Blog</a>
    <Button id="login_btn">LOGIN</Button>
    <Button id="signup_btn">SIGN UP</Button>
    <select name="" id="">
        <option value="">EN</option>
        <option value="">ES</option>
    </select>
</div>`
}

export default nav