
const msgbox = ()=>{

    return `
    <h1>More than 18 000 companies worldwide trust DeskTime with their business</h1>
 <div id="msg">
    
    <img id="scrollL" src="images1/icons8-right-button-50.png" alt="">
    <div id="msgimg">
        <div id="div1">
        <img src="images1/Web capture_8-11-2022_202816_desktime.com.jpeg" alt="">
        <img src="images1/Web capture_8-11-2022_202625_desktime.com.jpeg" alt="">
        <img src="images1/Web capture_8-11-2022_202951_desktime.com.jpeg" alt="">
        </div>
        <div id="div2">
        <img src="images1/Web capture_8-11-2022_202930_desktime.com.jpeg" alt="">
        <img src="images1/Web capture_8-11-2022_202816_desktime.com.jpeg" alt="">
        <img src="images1/Web capture_8-11-2022_202754_desktime.com.jpeg" alt="">
        </div>
        <div id="div3">
        <img src="images1/Web capture_8-11-2022_202731_desktime.com.jpeg" alt="">
        <img src="images1/Web capture_8-11-2022_20272_desktime.com.jpeg" alt="">
        <img src="images1/Web capture_8-11-2022_202625_desktime.com.jpeg" alt="">
        </div>
    </div>
    <img id="scrollR" src="images1/icons8-right-button-501.png" alt="">
 </div>
 <div id="scrollbtn">
    <button id="b1"></button>
    <button id="b2"></button>
    <button id="b3"></button>
 </div>
`
}

export default msgbox; 