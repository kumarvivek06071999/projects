# Time-Always
Clone of Desktime.com. It was our collaborative construct week project and we completed this in the span of 5 days in Masai. 
Time Always helps you to track your productive and unproductive time and calculate your productivity and effectiveness in your work.

<img src="https://drive.google.com/uc?export=view&id=1Gc6WmNLXvRM1jX3viQjiiksm6tiQDj0P" width="90%"> </img>


# Tech-Stack
 --Front-end---> HTML+CSS+JS <br/>
 --Back-end----> Heroku </br>

# Features 
--Login/Signup
--Email and Password Validation in the Signup form using Regex  <br/>
--Dashboard to track your total Productive and Unproductive time  <br/>
--Web Timer to track your time on a particular task  <br/>
--Reusable components  <br/>
--Expandable and Shirnkable side Navbar  <br/>
--Filter Projects by name and date  <br/>

# Deployed Link
<a href="https://time-always.netlify.app/">Demo</a>
